import App from '../../App';


export default function HomeScreen() {
  return (
    <App />
  );
}
