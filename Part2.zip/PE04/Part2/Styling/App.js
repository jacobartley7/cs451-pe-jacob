import React, { useState } from "react";
import { StyleSheet, Text, View, Image, TouchableHighlight, Platform } from "react-native";

const profileCardColor = "#1E90FF";

const ProfileCard = ({ image, name, occupation, description, isExpanded, onPress }) => {
  return (
    <TouchableHighlight onPress={onPress}>
      <View style={[styles.cardContainer, isExpanded ? styles.expanded : styles.thumbnail]}>
        <View style={styles.cardImageContainer}>
          <Image style={styles.cardImage} source={image} />
        </View>
        {isExpanded && (
          <>
            <Text style={styles.cardName}>{name}</Text>
            <Text style={styles.cardOccupation}>{occupation}</Text>
            <Text style={styles.cardDescription}>{description}</Text>
          </>
        )}
      </View>
    </TouchableHighlight>
  );
};

export default function App() {
  const [expandedIndex, setExpandedIndex] = useState(null);

  const profiles = [
    { id: 1, name: "John Doe", occupation: "JS Developer", description: "Loves React Native", image: require("./assets/profile.png") },
    { id: 2, name: "Jane Smith", occupation: "Designer", description: "Creative thinker", image: require("./assets/profile.png") },
    { id: 3, name: "Alice Brown", occupation: "Engineer", description: "Problem solver", image: require("./assets/profile.png") },
    { id: 4, name: "Bob White", occupation: "Manager", description: "Team leader", image: require("./assets/profile.png") },
    { id: 5, name: "Eva Green", occupation: "Tester", description: "Quality first", image: require("./assets/profile.png") },
    { id: 6, name: "Tom Black", occupation: "DevOps", description: "Keeps things running", image: require("./assets/profile.png") },
  ];

  return (
    <View style={styles.container}>
      {profiles.map((profile, index) => (
        <ProfileCard
          key={profile.id}
          {...profile}
          isExpanded={expandedIndex === index}
          onPress={() => setExpandedIndex(expandedIndex === index ? null : index)}
        />
      ))}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    flexDirection: "row",
    flexWrap: "wrap",
    justifyContent: "center",
    alignItems: "flex-start",
    backgroundColor: "#eee",
    padding: 10,
  },
  cardContainer: {
    alignItems: "center",
    borderColor: "black",
    borderWidth: 2,
    borderRadius: 15,
    backgroundColor: profileCardColor,
    margin: 10,
    ...Platform.select({
      ios: {
        shadowColor: "black",
        shadowOffset: { height: 5 },
        shadowOpacity: 0.5,
      },
      android: {
        elevation: 10,
      },
    }),
  },
  thumbnail: {
    width: 120,
    height: 160,
    justifyContent: "center",
    padding: 5,
  },
  expanded: {
    width: 280,
    height: 360,
    padding: 15,
  },
  cardImageContainer: {
    backgroundColor: "white",
    borderRadius: 60,
    marginBottom: 10,
    padding: 5,
  },
  cardImage: {
    width: 60,
    height: 60,
    borderRadius: 30,
  },
  cardName: {
    fontSize: 20,
    fontWeight: "bold",
    marginVertical: 5,
    color: "#fff",
  },
  cardOccupation: {
    fontSize: 16,
    color: "#fff",
  },
  cardDescription: {
    fontSize: 14,
    color: "#fff",
    marginTop: 5,
    textAlign: "center",
  },
});
