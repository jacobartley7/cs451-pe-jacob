// App.js (project root)
import React, { Component } from 'react';
import { View, Image, Text, StyleSheet } from 'react-native';

export default class App extends Component {
  render() {
    return (
      <View style={styles.container}>
        <View style={styles.card}>
          {/* avatar */}
          <View style={styles.avatarRing}>
            <Image
              source={require('./assets/images/user.png')}
              style={styles.avatar}
              resizeMode="contain"
            />
          </View>

          {/* name */}
          <Text style={styles.name}>John Doe</Text>

          {/* role / occupation */}
          <Text style={styles.role}>React Native Developer</Text>

          {/* divider */}
          <View style={styles.rule} />

          {/* description */}
          <Text style={styles.description}>
            John is a really great JavaScript developer. He loves using JS to
            build React Native applications for iOS and Android.
          </Text>
        </View>
      </View>
    );
  }
}

const CARD_COLOR = '#3b82c4'; // close to the blue in the mockup

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    justifyContent: 'center',
    alignItems: 'center',
  },

  card: {
    width: 300,
    height: 420,
    backgroundColor: CARD_COLOR,
    borderRadius: 22,
    borderWidth: 2,
    borderColor: '#222',
    paddingHorizontal: 16,
    paddingTop: 28,
    paddingBottom: 20,
    alignItems: 'center',

    // soft shadow like the mockup
    shadowColor: '#000',
    shadowOpacity: 0.2,
    shadowRadius: 6,
    shadowOffset: { width: 0, height: 3 },
    elevation: 5,
  },

  avatarRing: {
    width: 140,
    height: 140,
    borderRadius: 70,
    backgroundColor: '#fff',
    borderWidth: 3,
    borderColor: '#111',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 16,
  },

  avatar: {
    width: 90,
    height: 90,
  },

  name: {
    color: '#fff',
    fontSize: 18,
    fontWeight: '700',
    marginTop: 4,
  },

  role: {
    color: '#10324a',
    fontSize: 16,
    fontWeight: '700',
    textDecorationLine: 'underline',
    marginTop: 6,
    marginBottom: 8,
  },

  rule: {
    width: '86%',
    height: 1,
    backgroundColor: '#10324a',
    marginVertical: 6,
  },

  description: {
    color: '#0c2a40',
    fontSize: 14,
    lineHeight: 20,
    textAlign: 'left',
    width: '86%',
    marginTop: 4,
  },
});
